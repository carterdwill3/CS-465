/*
 * Travlr Getaways MVC Express Application
 * Carter Williams
 * CS-465 Full Stack Development
 * 16 July 2025
 */

const express = require('express');
const path = require('path');
const hbs = require('hbs');

const app = express();

// Import route modules - Carter Williams MVC implementation
const indexRouter = require('./app_server/routes/index');
const travelerRouter = require('./app_server/routes/traveler');

// Configure Handlebars view engine
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// Register partials directory for template components
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));

// Custom Handlebars helpers
hbs.registerHelper('currentYear', function() {
    return new Date().getFullYear();
});

hbs.registerHelper('formatPrice', function(price) {
    return '$' + price.toLocaleString();
});

// Static file serving middleware
app.use(express.static(path.join(__dirname, 'public')));

// Body parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Logging middleware
app.use((req, res, next) => {
    console.log(`${req.method} ${req.url} - Carter Williams Server`);
    next();
});

// Route handlers
app.use('/', indexRouter);
app.use('/traveler', travelerRouter);

// 404 error handling
app.use((req, res, next) => {
    const err = new Error('Page Not Found');
    err.status = 404;
    next(err);
});

// Error handler
app.use((err, req, res, next) => {
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};
    
    res.status(err.status || 500);
    res.render('error', { 
        title: 'Error - Travlr Getaways',
        error: err
    });
});

// Server configuration
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log('='.repeat(50));
    console.log('Travlr Getaways Server Started');
    console.log(`Carter Williams - CS-465`);
    console.log(`Port: ${PORT}`);
    console.log(`URL: http://localhost:${PORT}`);
    console.log('16 July 2025');
    console.log('='.repeat(50));
});

module.exports = app;