/*
 * Travlr Getaways Express Server
 * Author: Carter Williams
 * Date: 12 July 2025
 * CS 465 - Full Stack Development
 */

const express = require('express');
const path = require('path');

// Initialize Express application
const app = express();

// Configure static file serving from public directory
app.use(express.static(path.join(__dirname, 'public')));

// Route handlers for existing HTML pages
app.get('/', (req, res) => {
  console.log('Serving homepage to client - Carter Williams');
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/travel', (req, res) => {
  console.log('Serving travel packages page - Carter Williams');
  res.sendFile(path.join(__dirname, 'public', 'travel.html'));
});

app.get('/about', (req, res) => {
  console.log('Serving about page - Carter Williams');
  res.sendFile(path.join(__dirname, 'public', 'about.html'));
});

app.get('/contact', (req, res) => {
  console.log('Serving contact page - Carter Williams');
  res.sendFile(path.join(__dirname, 'public', 'contact.html'));
});

app.get('/meals', (req, res) => {
  console.log('Serving meals page - Carter Williams');
  res.sendFile(path.join(__dirname, 'public', 'meals.html'));
});

app.get('/news', (req, res) => {
  console.log('Serving news page - Carter Williams');
  res.sendFile(path.join(__dirname, 'public', 'news.html'));
});

app.get('/rooms', (req, res) => {
  console.log('Serving rooms page - Carter Williams');
  res.sendFile(path.join(__dirname, 'public', 'rooms.html'));
});

// Error handling for 404 pages
app.use((req, res) => {
  console.log(`404 Error: Page not found - ${req.url} - Carter Williams`);
  res.status(404).send(`
    <html>
      <head><title>Page Not Found - Travlr Getaways</title></head>
      <body style="font-family: Arial, sans-serif; text-align: center; margin-top: 50px;">
        <h1>404 - Page Not Found</h1>
        <p>The page you're looking for doesn't exist.</p>
        <p><a href="/">Return to Homepage</a></p>
        <hr>
        <small>Travlr Getaways Server - Carter Williams - 12 July 2025</small>
      </body>
    </html>
  `);
});

// Server configuration
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log('='.repeat(50));
  console.log('Travlr Getaways Server Started Successfully');
  console.log(`Developer: Carter Williams`);
  console.log(`Date: 12 July 2025`);
  console.log(`Server running on port ${PORT}`);
  console.log(`Access the website at: http://localhost:${PORT}`);
  console.log('='.repeat(50));
});

module.exports = app;